import React, { useCallback, useState } from 'react';
import { View, Text, Alert } from 'react-native';
import { useFocusEffect } from 'expo-router';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { db } from '../src/db';
import { getSession } from '../src/session';
import { C, money } from '../src/theme';
import { bdSql, businessDayDate, csvCell, localDateTimeString } from '../src/businessDay';
import { Screen, Card, Btn, Segmented, SectionTitle, Empty, useAuth } from '../src/ui';

type Range = 'today' | '7' | '30' | 'all';

export default function Reports() {
  const u = useAuth();
  const [range, setRange] = useState<Range>('today');
  const [days, setDays] = useState<any[]>([]);
  const [sales, setSales] = useState(0);
  const [cost, setCost] = useState(0);
  const [expenses, setExpenses] = useState(0);

  const load = useCallback((r: Range) => {
    try {
      const since = r === 'all' ? '0000-00-00' : businessDayDate(new Date(Date.now() - (r === 'today' ? 0 : Number(r) - 1) * 86400000));
      const bd = bdSql('b.created_at');
      setDays(db.getAllSync<any>(`SELECT ${bd} day, COUNT(*) count, COALESCE(SUM(b.total),0) sales FROM bills b WHERE ${bd}>=? GROUP BY ${bd} ORDER BY day DESC`, [since]));
      setSales(Number(db.getFirstSync<any>(`SELECT COALESCE(SUM(b.total),0) v FROM bills b WHERE ${bd}>=?`, [since])?.v || 0));
      setCost(Number(db.getFirstSync<any>(`SELECT COALESCE(SUM(bi.qty*COALESCE(NULLIF(bi.cost_price,0),p.cost,0)),0) v FROM bill_items bi JOIN bills b ON b.id=bi.bill_id LEFT JOIN products p ON p.id=bi.product_id WHERE ${bd}>=?`, [since])?.v || 0));
      setExpenses(Number(db.getFirstSync<any>(`SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE ${bdSql('created_at')}>=?`, [since])?.v || 0));
    } catch (e) { Alert.alert('Could not load reports', String(e)); }
  }, []);
  useFocusEffect(useCallback(() => { load(range); }, [load, range]));

  async function exportSessionCsv() {
    try {
      const s = getSession();
      const since = localDateTimeString(s?.sessionStartedAt ? new Date(s.sessionStartedAt) : new Date());
      const rows = db.getAllSync<any>(`SELECT b.id AS bill_no,b.created_at,b.cashier_name,b.payment,b.bill_type,b.subtotal,b.discount,b.gst,b.total AS bill_total,
        COALESCE(bi.product_name,CASE WHEN co.id IS NOT NULL THEN 'Cake Order - '||COALESCE(co.flavour,'')||' / '||COALESCE(co.weight,'') ELSE 'Bill item details unavailable' END) AS product_name,
        COALESCE(bi.qty,CASE WHEN co.id IS NOT NULL THEN 1 ELSE '' END) AS qty,
        COALESCE(bi.price,CASE WHEN co.id IS NOT NULL THEN co.total ELSE '' END) AS price,
        COALESCE(bi.gst_rate,0) AS gst_rate,
        COALESCE(bi.line_total,CASE WHEN co.id IS NOT NULL THEN co.total ELSE b.total END) AS line_total,
        COALESCE(bi.cost_price,0) AS cost_price,co.due_date,co.advance,co.status AS cake_status
        FROM bills b LEFT JOIN bill_items bi ON bi.bill_id=b.id LEFT JOIN cake_orders co ON co.completed_bill_id=b.id
        WHERE datetime(b.created_at)>=datetime(?) ORDER BY b.created_at,b.id,bi.id`, [since]);
      if (!rows.length) { Alert.alert('No session sales', 'No bills have been saved since this login session started.'); return; }
      const headers = ['Session Start','Bill ID','Date & Time','Billed By','Product / Cake Order','Qty','Price','GST %','Line Total','Subtotal','Discount','GST Total','Profit','Total Amount','Payment','Bill Type','Buy Cost','Cake Delivery Date','Cake Advance','Cake Status','Customer'];
      const customers = new Map<string, string>(db.getAllSync<any>('SELECT id,customer FROM bills WHERE created_at>=?', [since]).map(r => [r.id, r.customer] as [string, string]));
      const lines = [headers, ...rows.map(r => [since, r.bill_no, r.created_at, r.cashier_name, r.product_name, r.qty, r.price, r.gst_rate, r.line_total, r.subtotal, r.discount, r.gst,
        r.bill_type === 'Cake Order' ? '' : ((Number(r.price) || 0) - (Number(r.cost_price) || 0)) * (Number(r.qty) || 0),
        r.bill_total, r.payment, r.bill_type, r.cost_price, r.due_date || '', r.advance ?? '', r.cake_status || '', customers.get(r.bill_no) || 'Walk-in'])]
        .map(row => row.map(csvCell).join(',')).join('\r\n');
      const dir = FileSystem.cacheDirectory || FileSystem.documentDirectory;
      const path = `${dir}CAFFE_Session_Sales_${Date.now()}.csv`;
      await FileSystem.writeAsStringAsync(path, '\uFEFF' + lines, { encoding: FileSystem.EncodingType.UTF8 });
      if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(path, { mimeType: 'text/csv', dialogTitle: 'Export CAFFE session sales' });
      else Alert.alert('CSV saved', path);
    } catch (e) { Alert.alert('Export failed', String(e)); }
  }

  if (!u) return null;
  const rows: [string, number][] = [['Total sales', sales], ['Buy cost of sold items', cost], ['Gross item profit', sales - cost], ['Expenses', expenses], ['Profit after expenses', sales - cost - expenses]];
  return (
    <Screen title="Reports" subtitle="Day-by-day sales and item profit · local device data">
      <Segmented<Range> options={[['today', 'Today'], ['7', '7 days'], ['30', '30 days'], ['all', 'All']]} value={range} onChange={setRange} />
      <Card tone="brown" style={{ marginTop: 14 }}>
        {rows.map(([t, v], i) => (
          <View key={t} style={{ paddingVertical: 9, borderBottomWidth: i === rows.length - 1 ? 0 : 1, borderBottomColor: '#5A4333' }}>
            <Text style={{ color: C.sandDeep, fontSize: 12 }}>{t}</Text>
            <Text style={{ fontSize: 22, fontWeight: '900', color: i === rows.length - 1 ? '#F2C56B' : C.white, marginTop: 3 }}>{money(v)}</Text>
          </View>
        ))}
      </Card>
      <SectionTitle>Daily totals</SectionTitle>
      {days.map(d => (
        <Card key={d.day} style={{ marginBottom: 8, padding: 14 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ fontWeight: '900', color: C.ink }}>{d.day}</Text>
            <Text style={{ fontWeight: '900', color: C.brown }}>{money(d.sales)}</Text>
          </View>
          <Text style={{ color: C.muted, marginTop: 4 }}>{d.count} bills</Text>
        </Card>
      ))}
      {!days.length && <Empty text="No sales in this period." />}
      <SectionTitle>Export</SectionTitle>
      <Btn title="DOWNLOAD CURRENT SESSION CSV" variant="success" onPress={exportSessionCsv} />
      <Text style={{ color: C.muted, fontSize: 12, marginTop: 8 }}>Exports every bill saved since this login session started: bill ID, date/time, items, quantity, price, profit estimate, total and customer.</Text>
    </Screen>
  );
}
