import React, { useCallback, useState } from 'react';
import { View, Text, Alert } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { db } from '../src/db';
import { C } from '../src/theme';
import { localDateTimeString } from '../src/businessDay';
import { Screen, Card, Btn, Field, Empty, useAuth } from '../src/ui';

export default function Inventory() {
  const u = useAuth();
  const [rows, setRows] = useState<any[]>([]);
  const [delta, setDelta] = useState('1');
  const [reason, setReason] = useState('Stock count correction');
  const load = useCallback(() => setRows(db.getAllSync<any>('SELECT * FROM products WHERE active=1 ORDER BY stock ASC')), []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  function adjust(p: any) {
    if (!u) return;
    const d = Number(delta);
    if (!d || isNaN(d)) { Alert.alert('Enter quantity', 'Use a positive or negative number.'); return; }
    db.runSync('UPDATE products SET stock=MAX(0,stock+?) WHERE id=?', [d, p.id]);
    db.runSync('INSERT INTO stock_log(product_id,delta,reason,user_name,created_at) VALUES(?,?,?,?,?)', [p.id, d, reason, u.username, localDateTimeString()]);
    load();
  }
  if (!u) return null;
  return (
    <Screen title="Inventory" subtitle="Stock levels and adjustments">
      <Card tone="sand">
        <Field label="Adjustment amount" value={delta} onChangeText={setDelta} keyboardType="numbers-and-punctuation" />
        <Field label="Reason" value={reason} onChangeText={setReason} />
        <Text style={{ fontSize: 11, color: C.muted, marginTop: 6 }}>Positive = add stock · Negative = remove stock.</Text>
      </Card>
      <View style={{ marginTop: 14 }}>
        {rows.map(p => (
          <Card key={p.id} style={{ marginBottom: 8, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '900', color: C.ink }}>{p.name}</Text>
              <Text style={{ color: p.stock <= p.low_stock ? C.red : C.muted, marginTop: 4 }}>Stock {p.stock} · Low alert at {p.low_stock}</Text>
            </View>
            <Btn title="Apply" small variant="soft" onPress={() => adjust(p)} />
          </Card>
        ))}
        {!rows.length && <Empty text="No products yet." />}
      </View>
    </Screen>
  );
}
