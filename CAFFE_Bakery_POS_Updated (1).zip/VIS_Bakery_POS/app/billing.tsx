import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, Alert } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { db, nextBillNo } from '../src/db';
import { C, R, money } from '../src/theme';
import { localDateTimeString } from '../src/businessDay';
import { Screen, Card, Btn, Field, Segmented, useAuth, useLayout } from '../src/ui';

type Line = { id: number; name: string; price: number; cost: number; gst: number; stock: number; qty: number };
const r2 = (n: number) => Math.round(n * 100) / 100;

/** − [qty] +  control. Going below 1 removes the line. */
function Stepper({ qty, onChange, small }: { qty: number; onChange: (n: number) => void; small?: boolean }) {
  const [draft, setDraft] = useState(String(qty));
  useEffect(() => { setDraft(String(qty)); }, [qty]);
  const size = small ? 32 : 38;
  const btn = { width: size, height: size, borderRadius: size / 2, alignItems: 'center', justifyContent: 'center', backgroundColor: C.sand } as const;
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
      <Pressable accessibilityLabel="Decrease quantity" onPress={() => onChange(qty - 1)} style={btn}>
        <MaterialCommunityIcons name="minus" size={18} color={C.brownDark} />
      </Pressable>
      <TextInput
        value={draft} keyboardType="number-pad" selectTextOnFocus
        onChangeText={t => {
          const d = t.replace(/[^0-9]/g, '').slice(0, 4);
          setDraft(d);
          const n = Number(d);
          if (n > 0) onChange(n);
        }}
        onBlur={() => setDraft(String(qty))}
        style={{ minWidth: 46, height: size, textAlign: 'center', fontWeight: '900', color: C.ink, backgroundColor: C.cream, borderRadius: 8, borderWidth: 1, borderColor: C.sandDeep, paddingVertical: 0 }}
      />
      <Pressable accessibilityLabel="Increase quantity" onPress={() => onChange(qty + 1)} style={[btn, { backgroundColor: C.brown }]}>
        <MaterialCommunityIcons name="plus" size={18} color={C.white} />
      </Pressable>
    </View>
  );
}

export default function Billing() {
  const u = useAuth();
  const { isWide } = useLayout();
  const [products, setProducts] = useState<any[]>([]);
  const [cart, setCart] = useState<Line[]>([]);
  const [discount, setDiscount] = useState('');
  const [payment, setPayment] = useState('Cash');
  const [gstMode, setGstMode] = useState(true);
  const [customer, setCustomer] = useState('');
  const [search, setSearch] = useState('');
  const [tab, setTab] = useState<'products' | 'cart'>('products');

  const load = useCallback(() => {
    try { setProducts(db.getAllSync<any>('SELECT * FROM products WHERE active=1 ORDER BY priority ASC, name COLLATE NOCASE ASC')); }
    catch (e) { Alert.alert('Could not load products', String(e)); }
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const term = search.trim().toLowerCase();
  const shown = products.filter(p => !term
    || String(p.name || '').toLowerCase().includes(term)
    || String(p.barcode || '').toLowerCase().includes(term)
    || String(p.category || '').toLowerCase().includes(term))
    .sort((a, b) => {
      if (!term) return 0;
      const ar = String(a.name).toLowerCase().startsWith(term) ? 0 : 1;
      const br = String(b.name).toLowerCase().startsWith(term) ? 0 : 1;
      return ar - br;
    });

  const sub = r2(cart.reduce((s, l) => s + l.price * l.qty, 0));
  const disc = Math.min(sub, Math.max(0, Number(discount) || 0));
  const tax = gstMode ? r2(cart.reduce((s, l) => { const line = l.price * l.qty; return s + (line - (sub ? disc * (line / sub) : 0)) * l.gst / 100; }, 0)) : 0;
  const total = Math.max(0, r2(sub - disc + tax));
  const itemCount = cart.reduce((s, l) => s + l.qty, 0);
  const qtyOf = (id: number) => cart.find(l => l.id === id)?.qty || 0;

  function setQty(p: { id: number }, n: number) {
    setCart(old => n <= 0 ? old.filter(l => l.id !== p.id) : old.map(l => l.id === p.id ? { ...l, qty: Math.min(n, 9999) } : l));
  }
  function add(p: any) {
    setCart(old => {
      const f = old.find(l => l.id === p.id);
      if (f) return old.map(l => l.id === p.id ? { ...l, qty: l.qty + 1 } : l);
      return [...old, { id: p.id, name: p.name, price: Number(p.price) || 0, cost: Number(p.cost) || 0, gst: Number(p.gst) || 0, stock: Number(p.stock) || 0, qty: 1 }];
    });
  }
  function resetBill() { setCart([]); setDiscount(''); setCustomer(''); setPayment('Cash'); setTab('products'); }
  function clearBill() {
    if (!cart.length && !discount && !customer) return;
    Alert.alert('Clear bill', 'Remove all items from this bill?', [
      { text: 'Keep', style: 'cancel' },
      { text: 'Clear bill', style: 'destructive', onPress: resetBill },
    ]);
  }

  function save() {
    if (!u) return;
    if (!cart.length) { Alert.alert('Add products', 'Add at least one product.'); return; }
    if (payment === 'Credit' && !customer.trim()) { Alert.alert('Customer needed', 'Enter the customer name for a Credit bill.'); return; }
    const id = 'CAF-' + Date.now();
    const no = nextBillNo();
    const now = localDateTimeString();
    try {
      db.withTransactionSync(() => {
        db.runSync(
          'INSERT INTO bills(id,bill_no,user_id,cashier_name,customer,subtotal,discount,gst,total,payment,bill_type,created_at,synced) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0)',
          [id, no, u.id, u.full_name, customer.trim(), sub, disc, tax, total, payment, gstMode ? 'GST' : 'Normal', now],
        );
        cart.forEach(l => {
          db.runSync(
            'INSERT INTO bill_items(bill_id,product_id,product_name,qty,price,gst_rate,line_total,cost_price) VALUES(?,?,?,?,?,?,?,?)',
            [id, l.id, l.name, l.qty, l.price, gstMode ? l.gst : 0, r2(l.qty * l.price), l.cost],
          );
          db.runSync('UPDATE products SET stock=MAX(0,stock-?) WHERE id=?', [l.qty, l.id]);
          db.runSync('INSERT INTO stock_log(product_id,delta,reason,user_name,created_at) VALUES(?,?,?,?,?)', [l.id, -l.qty, 'Sale ' + id, u.username, now]);
        });
        if (payment === 'Credit' && customer.trim()) {
          db.runSync('UPDATE customers SET balance=balance+? WHERE lower(name)=lower(?)', [total, customer.trim()]);
        }
      });
    } catch (e) { Alert.alert('Could not save bill', String(e)); return; }
    Alert.alert('Bill saved', `Bill #${no}\nTotal ${money(total)}\nSaved on this device.`);
    resetBill(); load();
  }

  const renderProducts = () => (
    <ScrollView keyboardShouldPersistTaps="handled" style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 24 }}>
      <TextInput
        value={search} onChangeText={setSearch} autoCorrect={false} autoCapitalize="none"
        placeholder="Search product, barcode or category…" placeholderTextColor={C.muted}
        style={{ backgroundColor: C.white, padding: 13, borderRadius: R.md, marginBottom: 10, color: C.ink, borderWidth: 1, borderColor: C.sandDeep }}
      />
      {products.length === 0 ? (
        <Card tone="sand"><Text style={{ color: C.ink, fontWeight: '700' }}>No products added yet.</Text><Text style={{ color: C.muted, marginTop: 4 }}>Go to Products from the dashboard and add your bakery menu first.</Text></Card>
      ) : shown.length === 0 ? (
        <Card><Text style={{ color: C.muted }}>No matching products. Try another name or barcode.</Text></Card>
      ) : shown.map(p => {
        const q = qtyOf(p.id);
        const low = Number(p.stock) <= Number(p.low_stock);
        return (
          <View key={p.id} style={{ padding: 12, backgroundColor: q ? C.cream : C.white, borderRadius: R.md, marginBottom: 8, flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderColor: q ? C.brownSoft : C.line }}>
            <Pressable style={{ flex: 1 }} onPress={() => add(p)}>
              <Text style={{ fontWeight: '800', color: C.ink, fontSize: 15 }}>{p.name}</Text>
              <Text style={{ color: low ? C.red : C.muted, fontSize: 12, marginTop: 3 }}>{p.category} · Stock {p.stock}{GSTLabel(p.gst)}</Text>
              <Text style={{ fontWeight: '900', color: C.brown, marginTop: 4 }}>{money(p.price)}</Text>
            </Pressable>
            {q > 0 ? <Stepper small qty={q} onChange={n => setQty(p, n)} /> : (
              <Pressable onPress={() => add(p)} style={{ backgroundColor: C.brown, paddingVertical: 9, paddingHorizontal: 16, borderRadius: R.sm }}>
                <Text style={{ color: C.white, fontWeight: '900' }}>+ Add</Text>
              </Pressable>
            )}
          </View>
        );
      })}
    </ScrollView>
  );

  const renderCart = () => (
    <ScrollView keyboardShouldPersistTaps="handled" style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: 24 }}>
      <Segmented options={[['gst', 'GST bill'], ['normal', 'Normal bill']]} value={gstMode ? 'gst' : 'normal'} onChange={v => setGstMode(v === 'gst')} />
      <Field label="Customer (optional)" value={customer} onChangeText={setCustomer} placeholder="Customer name" />
      <Text style={{ fontSize: 18, fontWeight: '900', color: C.ink, marginTop: 18, marginBottom: 8 }}>Cart ({itemCount} items)</Text>
      {cart.length === 0 ? <Card tone="sand"><Text style={{ color: C.muted }}>Cart is empty. Add products from the Products tab.</Text></Card> : cart.map(l => (
        <View key={l.id} style={{ padding: 12, backgroundColor: C.white, borderRadius: R.md, marginBottom: 8, borderWidth: 1, borderColor: C.line }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: '800', color: C.ink }}>{l.name}</Text>
              <Text style={{ color: C.muted, marginTop: 2 }}>{money(l.price)} × {l.qty}</Text>
            </View>
            <Text style={{ fontWeight: '900', color: C.ink }}>{money(l.price * l.qty)}</Text>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 }}>
            <Stepper qty={l.qty} onChange={n => setQty(l, n)} />
            <Pressable accessibilityLabel={`Remove ${l.name}`} onPress={() => setQty(l, 0)} style={{ flexDirection: 'row', alignItems: 'center', gap: 4, padding: 8, borderRadius: R.sm, backgroundColor: C.redLight }}>
              <MaterialCommunityIcons name="trash-can-outline" size={18} color={C.red} />
              <Text style={{ color: C.red, fontWeight: '800', fontSize: 12 }}>Remove</Text>
            </Pressable>
          </View>
        </View>
      ))}
      <Field label="Discount amount ₹" value={discount} onChangeText={t => setDiscount(t.replace(/[^0-9.]/g, ''))} keyboardType="decimal-pad" placeholder="0" />
      <Card tone="brown" style={{ marginTop: 14 }}>
        {([['Subtotal', sub], ['Discount', -disc], ['GST', tax], ['TOTAL', total]] as [string, number][]).map(([label, val]) => (
          <View key={label} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 }}>
            <Text style={{ color: label === 'TOTAL' ? C.white : C.sandDeep, fontWeight: label === 'TOTAL' ? '900' : '500' }}>{label}</Text>
            <Text style={{ color: label === 'TOTAL' ? '#F2C56B' : C.white, fontSize: label === 'TOTAL' ? 23 : 15, fontWeight: '900' }}>{money(val)}</Text>
          </View>
        ))}
      </Card>
      <Text style={{ fontWeight: '900', color: C.ink, marginTop: 16, marginBottom: 8 }}>Payment method</Text>
      <Segmented options={[['Cash', 'Cash'], ['UPI', 'UPI'], ['Card', 'Card'], ['Credit', 'Credit']]} value={payment as any} onChange={setPayment} />
      <Btn title={`SAVE BILL  ·  ${money(total)}`} onPress={save} disabled={!cart.length} style={{ marginTop: 16 }} />
      <Btn title="CLEAR / CANCEL BILL" variant="danger" onPress={clearBill} disabled={!cart.length && !discount && !customer} style={{ marginTop: 10 }} />
    </ScrollView>
  );

  return (
    <Screen title="New bill" subtitle="Quick checkout" scroll={false} maxWidth={1180}>
      {!isWide && (
        <View style={{ marginBottom: 10 }}>
          <Segmented options={[['products', 'Products'], ['cart', `Cart (${itemCount})`]]} value={tab} onChange={setTab} />
        </View>
      )}
      <View style={{ flex: 1, flexDirection: 'row', gap: 16 }}>
        {(isWide || tab === 'products') && <View style={{ flex: 1 }}>{renderProducts()}</View>}
        {(isWide || tab === 'cart') && <View style={{ flex: 1 }}>{renderCart()}</View>}
      </View>
      {!isWide && tab === 'products' && cart.length > 0 && (
        <Pressable onPress={() => setTab('cart')} style={{ backgroundColor: C.brown, borderRadius: R.md, padding: 14, marginTop: 8, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text style={{ color: C.white, fontWeight: '800' }}>{itemCount} items · {money(total)}</Text>
          <Text style={{ color: C.white, fontWeight: '900' }}>VIEW CART ›</Text>
        </Pressable>
      )}
    </Screen>
  );
}

function GSTLabel(g: any) { return Number(g) ? ` · GST ${g}%` : ''; }
