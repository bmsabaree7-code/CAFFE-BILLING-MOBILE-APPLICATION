import React, { useCallback, useState } from 'react';
import { View, Text, Alert } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { db } from '../src/db';
import { C } from '../src/theme';
import { Screen, Card, Btn, Field, SectionTitle, Empty, useAuth } from '../src/ui';

export default function Purchases() {
  const u = useAuth();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [rows, setRows] = useState<any[]>([]);
  const load = useCallback(() => setRows(db.getAllSync<any>('SELECT * FROM suppliers ORDER BY name COLLATE NOCASE')), []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  function add() {
    if (!name.trim()) { Alert.alert('Required', 'Supplier name required.'); return; }
    db.runSync('INSERT INTO suppliers(name,phone) VALUES(?,?)', [name.trim(), phone.trim()]);
    setName(''); setPhone(''); load();
  }
  function remove(r: any) {
    Alert.alert('Delete supplier', `Delete ${r.name}?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => { db.runSync('DELETE FROM suppliers WHERE id=?', [r.id]); load(); } },
    ]);
  }
  if (!u) return null;
  return (
    <Screen title="Purchases" subtitle="Supplier directory">
      <Card tone="sand">
        <Text style={{ fontWeight: '900', color: C.ink, fontSize: 18 }}>Add supplier</Text>
        <Field label="Supplier name" value={name} onChangeText={setName} placeholder="Supplier name" />
        <Field label="Phone" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="Phone" />
        <Btn title="SAVE SUPPLIER" onPress={add} style={{ marginTop: 14 }} />
      </Card>
      <SectionTitle>Suppliers ({rows.length})</SectionTitle>
      {rows.map(r => (
        <Card key={r.id} style={{ marginBottom: 8, flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <View style={{ flex: 1 }}>
            <Text style={{ fontWeight: '900', color: C.ink }}>{r.name}</Text>
            <Text style={{ color: C.muted, marginTop: 4 }}>{r.phone || 'No phone'}</Text>
          </View>
          <Btn title="DELETE" small variant="danger" onPress={() => remove(r)} />
        </Card>
      ))}
      {!rows.length && <Empty text="No suppliers yet." />}
      <Text style={{ color: C.muted, fontSize: 12, marginTop: 12 }}>Supplier directory only. Purchase invoice entry and automatic stock-in are not implemented yet.</Text>
    </Screen>
  );
}
