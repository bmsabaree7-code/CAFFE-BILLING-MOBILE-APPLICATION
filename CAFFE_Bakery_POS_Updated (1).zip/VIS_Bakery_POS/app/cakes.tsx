import React, { useCallback, useState } from 'react';
import { View, Text, Alert } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { db, nextBillNo } from '../src/db';
import { C, R, money } from '../src/theme';
import { localDateTimeString, isValidDate, dateOffset } from '../src/businessDay';
import { Screen, Card, Btn, Field, SectionTitle, Empty, useAuth, useLayout } from '../src/ui';

export default function Cakes() {
  const u = useAuth();
  const { isTablet } = useLayout();
  const [rows, setRows] = useState<any[]>([]);
  const [customer, setCustomer] = useState('');
  const [phone, setPhone] = useState('');
  const [weight, setWeight] = useState('1 kg');
  const [flavour, setFlavour] = useState('Chocolate');
  const [design, setDesign] = useState('');
  const [date, setDate] = useState('');
  const [total, setTotal] = useState('');
  const [advance, setAdvance] = useState('0');
  const [notes, setNotes] = useState('');

  const load = useCallback(() => {
    try { setRows(db.getAllSync<any>('SELECT * FROM cake_orders ORDER BY id DESC')); }
    catch (e) { Alert.alert('Could not load orders', String(e)); }
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const num = (t: string) => t.replace(/[^0-9.]/g, '');

  function save() {
    if (!customer.trim() || Number(total) <= 0) { Alert.alert('Required', 'Customer name and total amount are required.'); return; }
    if (!isValidDate(date.trim())) { Alert.alert('Delivery date', 'Enter a valid date as YYYY-MM-DD, or tap Today / Tomorrow.'); return; }
    if ((Number(advance) || 0) > Number(total)) { Alert.alert('Advance', 'Advance cannot be more than the total amount.'); return; }
    try {
      db.runSync("INSERT INTO cake_orders(customer,phone,weight,flavour,design,due_date,total,advance,notes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,'Pending',?)",
        [customer.trim(), phone.trim(), weight, flavour, design, date.trim(), Number(total), Number(advance) || 0, notes, localDateTimeString()]);
    } catch (e) { Alert.alert('Could not save', String(e)); return; }
    setCustomer(''); setPhone(''); setDesign(''); setDate(''); setTotal(''); setAdvance('0'); setNotes(''); load();
    Alert.alert('Order saved', 'Status: Pending. Mark it Done when the order is completed.');
  }

  function complete(r: any) {
    if (!u || r.status === 'Done') return;
    Alert.alert('Complete order', `Mark ${r.customer}'s order completed and move it to Bill History?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Mark Done', onPress: () => {
        const bill = 'CAF-ORD-' + r.id + '-' + Date.now();
        try {
          db.withTransactionSync(() => {
            db.runSync("INSERT INTO bills(id,bill_no,user_id,cashier_name,customer,subtotal,discount,gst,total,payment,bill_type,created_at,synced) VALUES(?,?,?,?,?,?,0,0,?,'Cash','Cake Order',?,0)",
              [bill, nextBillNo(), u.id, u.full_name, r.customer, r.total, r.total, localDateTimeString()]);
            db.runSync("UPDATE cake_orders SET status='Done',completed_bill_id=? WHERE id=?", [bill, r.id]);
          });
        } catch (e) { Alert.alert('Could not complete', String(e)); return; }
        load(); Alert.alert('Completed', `Order moved to Bill History.\nBill: ${bill}`);
      } },
    ]);
  }

  function remove(r: any) {
    Alert.alert('Delete order', r.completed_bill_id ? 'Remove this order and its bill from history?' : 'Remove this order?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => {
        db.withTransactionSync(() => {
          if (r.completed_bill_id) {
            db.runSync('DELETE FROM bill_items WHERE bill_id=?', [r.completed_bill_id]);
            db.runSync('DELETE FROM bills WHERE id=?', [r.completed_bill_id]);
          }
          db.runSync('DELETE FROM cake_orders WHERE id=?', [r.id]);
        });
        load();
      } },
    ]);
  }

  if (!u) return null;
  const form = (
    <Card tone="sand" style={{ flex: isTablet ? 1 : undefined, width: isTablet ? undefined : '100%' }}>
      <Text style={{ fontSize: 18, fontWeight: '900', color: C.ink }}>New order</Text>
      <Field label="Customer name" value={customer} onChangeText={setCustomer} placeholder="Customer name" />
      <Field label="Phone" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="Phone number" />
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <View style={{ flex: 1 }}><Field label="Weight" value={weight} onChangeText={setWeight} /></View>
        <View style={{ flex: 1 }}><Field label="Flavour" value={flavour} onChangeText={setFlavour} /></View>
      </View>
      <Field label="Design / message" value={design} onChangeText={setDesign} placeholder="Design or message on cake" />
      <Field label="Delivery date (YYYY-MM-DD)" value={date} onChangeText={setDate} placeholder="2026-12-25" autoCapitalize="none" />
      <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
        <Btn title="Today" small variant="soft" onPress={() => setDate(dateOffset(0))} />
        <Btn title="Tomorrow" small variant="soft" onPress={() => setDate(dateOffset(1))} />
      </View>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <View style={{ flex: 1 }}><Field label="Total ₹" value={total} onChangeText={t => setTotal(num(t))} keyboardType="decimal-pad" placeholder="0" /></View>
        <View style={{ flex: 1 }}><Field label="Advance ₹" value={advance} onChangeText={t => setAdvance(num(t))} keyboardType="decimal-pad" /></View>
      </View>
      <Field label="Notes" value={notes} onChangeText={setNotes} />
      <Btn title="SAVE PENDING ORDER" onPress={save} style={{ marginTop: 14 }} />
    </Card>
  );

  const list = (
    <View style={{ flex: isTablet ? 1.2 : undefined, width: isTablet ? undefined : '100%' }}>
      <SectionTitle>Orders ({rows.length})</SectionTitle>
      {rows.map(r => {
        const done = r.status === 'Done';
        return (
          <Card key={r.id} style={{ marginBottom: 10 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 8 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontWeight: '900', fontSize: 16, color: C.ink }}>{r.customer} · {r.weight}</Text>
                <Text style={{ color: C.muted, marginTop: 4 }}>{r.flavour} · Due {r.due_date}</Text>
                {r.design ? <Text style={{ color: C.muted, marginTop: 2 }}>{r.design}</Text> : null}
                <Text style={{ color: C.muted, marginTop: 3 }}>Total {money(r.total)} · Advance {money(r.advance)} · Balance {money(r.total - r.advance)}</Text>
              </View>
              <View style={{ backgroundColor: done ? C.greenLight : C.sand, paddingVertical: 6, paddingHorizontal: 10, borderRadius: R.sm, alignSelf: 'flex-start' }}>
                <Text style={{ fontWeight: '900', color: done ? C.green : C.brownDark, fontSize: 12 }}>{done ? 'DONE' : 'PENDING'}</Text>
              </View>
            </View>
            {!done && <Btn title="MARK DONE → MOVE TO BILL HISTORY" variant="success" onPress={() => complete(r)} style={{ marginTop: 12 }} />}
            {done && <Text style={{ color: C.green, fontWeight: '800', marginTop: 10 }}>Bill: {r.completed_bill_id || 'Completed'}</Text>}
            <Btn title="DELETE ORDER" small variant="danger" onPress={() => remove(r)} style={{ marginTop: 8 }} />
          </Card>
        );
      })}
      {!rows.length && <Empty text="No cake orders yet." />}
    </View>
  );

  return (
    <Screen title="Cake orders" subtitle="Pending orders become bills when marked Done">
      <View style={{ flexDirection: isTablet ? 'row' : 'column', gap: 16, alignItems: 'flex-start' }}>
        {form}
        {list}
      </View>
    </Screen>
  );
}
