import React, { useCallback, useState } from 'react';
import { View, Text, Alert } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { db } from '../src/db';
import { C, money } from '../src/theme';
import { localDateTimeString } from '../src/businessDay';
import { Screen, Card, Btn, Field, SectionTitle, Empty, useAuth } from '../src/ui';

export default function Expenses() {
  const u = useAuth();
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [rows, setRows] = useState<any[]>([]);
  const load = useCallback(() => setRows(db.getAllSync<any>('SELECT * FROM expenses ORDER BY id DESC LIMIT 300')), []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  function add() {
    if (!title.trim() || !(Number(amount) > 0)) { Alert.alert('Required', 'Enter expense description and amount.'); return; }
    db.runSync('INSERT INTO expenses(title,amount,created_at) VALUES(?,?,?)', [title.trim(), Number(amount), localDateTimeString()]);
    setTitle(''); setAmount(''); load();
  }
  function remove(r: any) {
    Alert.alert('Delete expense', `Delete "${r.title}"?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => { db.runSync('DELETE FROM expenses WHERE id=?', [r.id]); load(); } },
    ]);
  }
  if (!u) return null;
  return (
    <Screen title="Expenses" subtitle="Shop expense tracker">
      <Card tone="sand">
        <Field label="Description" value={title} onChangeText={setTitle} placeholder="e.g. Milk, electricity" />
        <Field label="Amount ₹" value={amount} onChangeText={t => setAmount(t.replace(/[^0-9.]/g, ''))} keyboardType="decimal-pad" placeholder="0" />
        <Btn title="SAVE EXPENSE" onPress={add} style={{ marginTop: 14 }} />
      </Card>
      <SectionTitle>Recent expenses</SectionTitle>
      {rows.map(r => (
        <Card key={r.id} style={{ marginBottom: 8, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
          <View style={{ flex: 1 }}>
            <Text style={{ fontWeight: '800', color: C.ink }}>{r.title}</Text>
            <Text style={{ color: C.muted, fontSize: 11, marginTop: 2 }}>{String(r.created_at).slice(0, 16)}</Text>
          </View>
          <Text style={{ fontWeight: '900', color: C.red }}>{money(r.amount)}</Text>
          <Btn title="✕" small variant="danger" onPress={() => remove(r)} />
        </Card>
      ))}
      {!rows.length && <Empty text="No expenses recorded." />}
    </Screen>
  );
}
