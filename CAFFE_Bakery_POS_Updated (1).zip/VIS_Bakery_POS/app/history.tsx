import React, { useCallback, useState } from 'react';
import { View, Text, Pressable, Alert } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { db } from '../src/db';
import { C, money } from '../src/theme';
import { Screen, Card, Btn, Empty, useAuth } from '../src/ui';

export default function History() {
  const u = useAuth();
  const [rows, setRows] = useState<any[]>([]);
  const [open, setOpen] = useState<string | null>(null);
  const [items, setItems] = useState<any[]>([]);
  const load = useCallback(() => setRows(db.getAllSync<any>('SELECT * FROM bills ORDER BY created_at DESC, id DESC LIMIT 200')), []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  function toggle(b: any) {
    if (open === b.id) { setOpen(null); return; }
    setItems(db.getAllSync<any>('SELECT * FROM bill_items WHERE bill_id=? ORDER BY id', [b.id]));
    setOpen(b.id);
  }
  function removeBill(b: any) {
    Alert.alert('Delete bill', `Delete ${b.id}? Stock from this bill is returned. This cannot be undone.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => {
        try {
          db.withTransactionSync(() => {
            const its = db.getAllSync<any>('SELECT * FROM bill_items WHERE bill_id=?', [b.id]);
            its.forEach(i => { if (i.product_id) db.runSync('UPDATE products SET stock=stock+? WHERE id=?', [i.qty, i.product_id]); });
            if (b.payment === 'Credit' && b.customer) db.runSync('UPDATE customers SET balance=MAX(0,balance-?) WHERE lower(name)=lower(?)', [b.total, b.customer]);
            db.runSync('DELETE FROM bill_items WHERE bill_id=?', [b.id]);
            db.runSync('DELETE FROM bills WHERE id=?', [b.id]);
          });
        } catch (e) { Alert.alert('Could not delete', String(e)); return; }
        setOpen(null); load();
      } },
    ]);
  }
  if (!u) return null;
  return (
    <Screen title="Bill history" subtitle="Most recent 200 bills · tap a bill for details">
      {rows.map(b => (
        <Card key={b.id} style={{ marginBottom: 8, padding: 0 }}>
          <Pressable onPress={() => toggle(b)} style={{ padding: 14 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontWeight: '900', color: C.ink }}>{b.bill_no ? `Bill #${b.bill_no}` : b.id}</Text>
                <Text style={{ color: C.muted, marginTop: 4 }}>{b.customer || 'Walk-in'} · {b.payment} · {b.bill_type}</Text>
                <Text style={{ color: C.muted, fontSize: 11, marginTop: 3 }}>{b.created_at}</Text>
              </View>
              <Text style={{ fontWeight: '900', color: C.brown, fontSize: 16 }}>{money(b.total)}</Text>
            </View>
          </Pressable>
          {open === b.id && (
            <View style={{ paddingHorizontal: 14, paddingBottom: 14, borderTopWidth: 1, borderTopColor: C.line }}>
              <Text style={{ color: C.muted, fontSize: 11, marginTop: 10 }}>{b.id}</Text>
              {items.length ? items.map(i => (
                <View key={i.id} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 }}>
                  <Text style={{ color: C.ink, flex: 1 }}>{i.product_name} × {i.qty}</Text>
                  <Text style={{ color: C.ink, fontWeight: '700' }}>{money(i.line_total)}</Text>
                </View>
              )) : <Text style={{ color: C.muted, paddingVertical: 6 }}>No item details (cake order or removed items).</Text>}
              <View style={{ marginTop: 6, paddingTop: 6, borderTopWidth: 1, borderTopColor: C.line }}>
                {([['Subtotal', b.subtotal], ['Discount', -b.discount], ['GST', b.gst], ['Total', b.total]] as [string, number][]).map(([l, v]) => (
                  <View key={l} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 2 }}>
                    <Text style={{ color: C.muted }}>{l}</Text><Text style={{ color: C.ink, fontWeight: l === 'Total' ? '900' : '600' }}>{money(v)}</Text>
                  </View>
                ))}
              </View>
              <Btn title="DELETE BILL" small variant="danger" onPress={() => removeBill(b)} style={{ marginTop: 12 }} />
            </View>
          )}
        </Card>
      ))}
      {!rows.length && <Empty text="No bills saved yet." />}
    </Screen>
  );
}
