import React, { useState } from 'react';
import { Text, Alert } from 'react-native';
import { db, hashPassword } from '../src/db';
import { setSession } from '../src/session';
import { C } from '../src/theme';
import { Screen, Card, Btn, Field, useAuth } from '../src/ui';

export default function Settings() {
  const u = useAuth();
  const [username, setUsername] = useState(u?.username || 'ADMIN');
  const [oldPass, setOldPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirm, setConfirm] = useState('');

  async function save() {
    if (!u) return;
    const row = db.getFirstSync<any>('SELECT * FROM users WHERE id=?', [u.id]);
    if (!row || (await hashPassword(oldPass)) !== row.password_hash) { Alert.alert('Verify password', 'Enter your current password.'); return; }
    if (!username.trim()) { Alert.alert('Required', 'Username cannot be empty.'); return; }
    if (newPass && newPass.length < 8) { Alert.alert('Weak password', 'Use at least 8 characters.'); return; }
    if (newPass && newPass !== confirm) { Alert.alert('Mismatch', 'New passwords do not match.'); return; }
    try {
      if (newPass) db.runSync('UPDATE users SET username=?,password_hash=? WHERE id=?', [username.trim(), await hashPassword(newPass), u.id]);
      else db.runSync('UPDATE users SET username=? WHERE id=?', [username.trim(), u.id]);
      setSession({ ...u, username: username.trim() });
      setOldPass(''); setNewPass(''); setConfirm('');
      Alert.alert('Saved', 'Admin login details updated.');
    } catch { Alert.alert('Username unavailable', 'Choose another username.'); }
  }

  if (!u) return null;
  return (
    <Screen title="Admin security" subtitle="Change your login credentials" maxWidth={620}>
      <Card tone="sand">
        <Text style={{ color: C.ink, fontWeight: '900', fontSize: 18 }}>Account details</Text>
        <Field label="Username" value={username} onChangeText={setUsername} autoCapitalize="none" />
        <Field label="Current password" value={oldPass} onChangeText={setOldPass} secureTextEntry autoCapitalize="none" />
        <Field label="New password (optional, 8+ chars)" value={newPass} onChangeText={setNewPass} secureTextEntry autoCapitalize="none" />
        <Field label="Confirm new password" value={confirm} onChangeText={setConfirm} secureTextEntry autoCapitalize="none" />
        <Btn title="SAVE CREDENTIALS" onPress={save} style={{ marginTop: 16 }} />
      </Card>
      <Text style={{ color: C.muted, fontSize: 12, marginTop: 14 }}>Change the default ADMIN123 password before using this app with real business data.</Text>
    </Screen>
  );
}
