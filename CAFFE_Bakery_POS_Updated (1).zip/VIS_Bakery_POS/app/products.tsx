import React, { useCallback, useRef, useState } from 'react';
import { View, Text, Pressable, Alert, ScrollView } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { db } from '../src/db';
import { C, R, money } from '../src/theme';
import { Screen, Card, Btn, Field, SectionTitle, Empty, useAuth, useLayout } from '../src/ui';

export default function Products() {
  const u = useAuth();
  const { isTablet } = useLayout();
  const scrollRef = useRef<ScrollView>(null);
  const [items, setItems] = useState<any[]>([]);
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [cost, setCost] = useState('');
  const [gst, setGst] = useState('0');
  const [stock, setStock] = useState('0');
  const [low, setLow] = useState('5');
  const [category, setCategory] = useState('Bakery');
  const [barcode, setBarcode] = useState('');
  const [editId, setEditId] = useState<number | null>(null);

  const load = useCallback(() => {
    try { setItems(db.getAllSync<any>('SELECT * FROM products WHERE active=1 ORDER BY name COLLATE NOCASE')); }
    catch (e) { Alert.alert('Could not load products', String(e)); }
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const num = (t: string) => t.replace(/[^0-9.]/g, '');

  function clear() { setEditId(null); setName(''); setPrice(''); setCost(''); setGst('0'); setStock('0'); setLow('5'); setCategory('Bakery'); setBarcode(''); }

  function save() {
    if (!name.trim() || price.trim() === '' || cost.trim() === '' || isNaN(Number(price)) || isNaN(Number(cost))) {
      Alert.alert('Required', 'Enter product name, buy cost and selling price.'); return;
    }
    const vals = [name.trim(), category.trim() || 'Bakery', Number(price), Number(cost), Number(gst) || 0, Number(stock) || 0, Number(low) || 0, barcode.trim()];
    try {
      if (editId !== null) db.runSync('UPDATE products SET name=?,category=?,price=?,cost=?,gst=?,stock=?,low_stock=?,barcode=? WHERE id=?', [...vals, editId]);
      else db.runSync('INSERT INTO products(name,category,price,cost,gst,stock,low_stock,barcode) VALUES(?,?,?,?,?,?,?,?)', vals);
    } catch (e) { Alert.alert('Could not save', String(e)); return; }
    clear(); load(); Alert.alert('Saved', 'Product saved.');
  }

  function edit(p: any) {
    setEditId(p.id); setName(String(p.name ?? '')); setPrice(String(p.price ?? '')); setCost(String(p.cost ?? ''));
    setGst(String(p.gst ?? 0)); setStock(String(p.stock ?? 0)); setLow(String(p.low_stock ?? 5));
    setCategory(String(p.category ?? 'Bakery')); setBarcode(String(p.barcode ?? ''));
    scrollRef.current?.scrollTo({ y: 0, animated: true });
  }

  function remove(p: any) {
    Alert.alert('Remove product', `Remove ${p.name} from active products? Old bills will remain in history.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'DELETE PRODUCT', style: 'destructive', onPress: () => { db.runSync('UPDATE products SET active=0 WHERE id=?', [p.id]); load(); if (editId === p.id) clear(); } },
    ]);
  }

  if (!u) return null;
  const form = (
    <Card tone="sand" style={{ flex: isTablet ? 1 : undefined, width: isTablet ? undefined : '100%' }}>
      <Text style={{ fontSize: 19, fontWeight: '900', color: C.ink }}>{editId !== null ? 'Edit product' : 'Add product'}</Text>
      <Field label="Product name" value={name} onChangeText={setName} placeholder="e.g. Butter Croissant" />
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <View style={{ flex: 1 }}><Field label="Buy cost ₹" value={cost} onChangeText={t => setCost(num(t))} keyboardType="decimal-pad" placeholder="0" /></View>
        <View style={{ flex: 1 }}><Field label="Selling price ₹" value={price} onChangeText={t => setPrice(num(t))} keyboardType="decimal-pad" placeholder="0" /></View>
      </View>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <View style={{ flex: 1 }}><Field label="GST %" value={gst} onChangeText={t => setGst(num(t))} keyboardType="decimal-pad" /></View>
        <View style={{ flex: 1 }}><Field label="Stock" value={stock} onChangeText={t => setStock(num(t))} keyboardType="decimal-pad" /></View>
        <View style={{ flex: 1 }}><Field label="Low alert" value={low} onChangeText={t => setLow(num(t))} keyboardType="decimal-pad" /></View>
      </View>
      <Field label="Category" value={category} onChangeText={setCategory} />
      <Field label="Barcode (optional)" value={barcode} onChangeText={setBarcode} />
      <Btn title={editId !== null ? 'SAVE PRODUCT CHANGES' : 'SAVE NEW PRODUCT'} onPress={save} style={{ marginTop: 14 }} />
      {editId !== null && <Btn title="CANCEL EDIT" variant="ghost" onPress={clear} style={{ marginTop: 8 }} />}
    </Card>
  );

  const list = (
    <View style={{ flex: isTablet ? 1.2 : undefined, width: isTablet ? undefined : '100%' }}>
      {!isTablet && <SectionTitle>Menu ({items.length})</SectionTitle>}
      {items.map(p => {
        const lowStock = Number(p.stock) <= Number(p.low_stock);
        return (
          <Card key={p.id} style={{ marginBottom: 10 }}>
            <Text style={{ fontSize: 17, fontWeight: '900', color: C.ink }}>{p.name}</Text>
            <Text style={{ color: C.muted, marginTop: 4 }}>{p.category} · GST {p.gst}%</Text>
            <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
              <View style={{ flex: 1, backgroundColor: C.bg, padding: 10, borderRadius: R.sm }}><Text style={{ color: C.muted, fontSize: 11 }}>BUY COST</Text><Text style={{ fontWeight: '900', color: C.ink }}>{money(p.cost)}</Text></View>
              <View style={{ flex: 1, backgroundColor: C.bg, padding: 10, borderRadius: R.sm }}><Text style={{ color: C.muted, fontSize: 11 }}>SELLING PRICE</Text><Text style={{ fontWeight: '900', color: C.ink }}>{money(p.price)}</Text></View>
            </View>
            <Text style={{ color: lowStock ? C.red : C.green, fontWeight: '800', marginTop: 10 }}>Stock: {p.stock} · Low-stock alert at: {p.low_stock}</Text>
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 12 }}>
              <Btn title="EDIT" small onPress={() => edit(p)} style={{ flex: 1 }} />
              <Btn title="DELETE" small variant="danger" onPress={() => remove(p)} style={{ flex: 1 }} />
            </View>
          </Card>
        );
      })}
      {!items.length && <Empty text="No products yet. Add your first product." />}
    </View>
  );

  return (
    <Screen title="Products" subtitle="Buy cost, selling price, stock and low-stock alert" scrollRef={scrollRef}>
      <View style={{ flexDirection: isTablet ? 'row' : 'column', gap: 16, alignItems: 'flex-start' }}>
        {form}
        {list}
      </View>
    </Screen>
  );
}
