import React, { useCallback, useState } from 'react';
import { View, Text, Alert } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { db } from '../src/db';
import { C, money } from '../src/theme';
import { Screen, Card, Btn, Field, SectionTitle, Empty, useAuth } from '../src/ui';

export default function Customers() {
  const u = useAuth();
  const [rows, setRows] = useState<any[]>([]);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const load = useCallback(() => setRows(db.getAllSync<any>('SELECT * FROM customers ORDER BY name COLLATE NOCASE')), []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  function add() {
    if (!name.trim()) { Alert.alert('Required', 'Enter customer name.'); return; }
    db.runSync('INSERT INTO customers(name,phone,notes) VALUES(?,?,?)', [name.trim(), phone.trim(), notes.trim()]);
    setName(''); setPhone(''); setNotes(''); load();
  }
  function clearBalance(r: any) {
    Alert.alert('Clear credit', `Mark ${r.name}'s credit balance of ${money(r.balance)} as paid?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Mark paid', onPress: () => { db.runSync('UPDATE customers SET balance=0 WHERE id=?', [r.id]); load(); } },
    ]);
  }
  function remove(r: any) {
    Alert.alert('Delete customer', `Delete ${r.name}? Past bills are kept.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => { db.runSync('DELETE FROM customers WHERE id=?', [r.id]); load(); } },
    ]);
  }
  if (!u) return null;
  return (
    <Screen title="Customers" subtitle="Customer book and credit balance">
      <Card tone="sand">
        <Field label="Customer name" value={name} onChangeText={setName} placeholder="Customer name" />
        <Field label="Phone" value={phone} onChangeText={setPhone} keyboardType="phone-pad" placeholder="Phone number" />
        <Field label="Notes" value={notes} onChangeText={setNotes} placeholder="Notes" />
        <Btn title="ADD CUSTOMER" onPress={add} style={{ marginTop: 14 }} />
      </Card>
      <SectionTitle>Customers ({rows.length})</SectionTitle>
      {rows.map(r => (
        <Card key={r.id} style={{ marginBottom: 8 }}>
          <Text style={{ fontWeight: '900', fontSize: 16, color: C.ink }}>{r.name}</Text>
          <Text style={{ color: C.muted, marginTop: 4 }}>{r.phone || 'No phone'}{r.notes ? ' · ' + r.notes : ''}</Text>
          <Text style={{ color: r.balance > 0 ? C.red : C.green, fontWeight: '800', marginTop: 7 }}>Credit balance {money(r.balance)}</Text>
          <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
            {r.balance > 0 && <Btn title="MARK PAID" small variant="success" onPress={() => clearBalance(r)} style={{ flex: 1 }} />}
            <Btn title="DELETE" small variant="danger" onPress={() => remove(r)} style={{ flex: 1 }} />
          </View>
        </Card>
      ))}
      {!rows.length && <Empty text="No customers yet." />}
    </Screen>
  );
}
