import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TextInput, Pressable, KeyboardAvoidingView, Platform, Alert, ScrollView } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { db, initDb, hashPassword } from '../src/db';
import { setSession } from '../src/session';
import { C, R } from '../src/theme';
import { Btn } from '../src/ui';

export default function Login() {
  const ins = useSafeAreaInsets();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const passwordRef = useRef<TextInput>(null);

  useEffect(() => {
    initDb().then(() => setReady(true)).catch(e => Alert.alert('Database error', String(e)));
  }, []);

  async function login() {
    if (!ready || busy) return;
    if (!username.trim() || !password) { Alert.alert('Sign in', 'Enter username and password.'); return; }
    setBusy(true);
    try {
      const u = db.getFirstSync<any>("SELECT * FROM users WHERE lower(username)=lower(?) AND role='admin' AND enabled=1", [username.trim()]);
      if (!u) { Alert.alert('Login failed', 'Account not found or disabled.'); return; }
      const h = await hashPassword(password);
      if (h !== u.password_hash) { Alert.alert('Login failed', 'Check username and password.'); return; }
      setSession({ id: u.id, username: u.username, role: 'admin', full_name: u.full_name });
      setPassword('');
      router.replace('/home');
    } catch (e) {
      Alert.alert('Login error', String(e));
    } finally {
      setBusy(false);
    }
  }

  const input = { backgroundColor: C.white, borderWidth: 1, borderColor: C.sandDeep, borderRadius: R.sm, color: C.ink, fontSize: 15 } as const;

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: C.bg }}>
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 22, paddingTop: ins.top + 22, paddingBottom: ins.bottom + 30 }}>
        <View style={{ width: '100%', maxWidth: 440, alignSelf: 'center' }}>
          <View style={{ alignItems: 'center', marginBottom: 26 }}>
            <Text style={{ fontSize: 40, fontWeight: '900', color: C.brownDark, letterSpacing: 8 }}>CAFFE</Text>
            <Text style={{ color: C.brownSoft, fontSize: 13, marginTop: 6, letterSpacing: 3 }}>BAKERY POS</Text>
            <View style={{ height: 3, width: 56, backgroundColor: C.sandDeep, borderRadius: 3, marginTop: 16 }} />
          </View>
          <View style={{ backgroundColor: C.white, padding: 22, borderRadius: 24, borderWidth: 1, borderColor: C.line }}>
            <Text style={{ fontSize: 22, color: C.ink, fontWeight: '900' }}>Welcome back</Text>
            <Text style={{ color: C.muted, marginTop: 4, marginBottom: 18 }}>Sign in to your bakery workspace</Text>
            <Text style={{ color: C.brownSoft, fontWeight: '700', fontSize: 12, marginBottom: 6 }}>USERNAME</Text>
            <TextInput
              value={username} onChangeText={setUsername} returnKeyType="next" blurOnSubmit={false}
              onSubmitEditing={() => passwordRef.current?.focus()} autoCapitalize="none" autoCorrect={false}
              placeholder="Enter username" placeholderTextColor={C.muted} style={[input, { padding: 14 }]}
            />
            <Text style={{ color: C.brownSoft, fontWeight: '700', fontSize: 12, marginTop: 14, marginBottom: 6 }}>PASSWORD</Text>
            <View style={[input, { flexDirection: 'row', alignItems: 'center' }]}>
              <TextInput
                ref={passwordRef} value={password} onChangeText={setPassword} returnKeyType="go" onSubmitEditing={login}
                secureTextEntry={!showPassword} autoCapitalize="none" placeholder="Enter password" placeholderTextColor={C.muted}
                style={{ flex: 1, color: C.ink, padding: 14, fontSize: 15 }}
              />
              <Pressable accessibilityLabel={showPassword ? 'Hide password' : 'Show password'} onPress={() => setShowPassword(v => !v)} style={{ padding: 13 }}>
                <Ionicons name={showPassword ? 'eye-off-outline' : 'eye-outline'} size={22} color={C.brownSoft} />
              </Pressable>
            </View>
            <Btn title={ready ? (busy ? 'SIGNING IN…' : 'SIGN IN  →') : 'PREPARING DATABASE…'} onPress={login} disabled={!ready || busy} style={{ marginTop: 18 }} />
            <Text style={{ color: C.muted, fontSize: 11, textAlign: 'center', marginTop: 14 }}>Local offline mode • Session expires after 24 hours</Text>
          </View>
          <Text style={{ color: C.muted, textAlign: 'center', marginTop: 20, fontSize: 12 }}>CAFFE • Crafted for bakery businesses</Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
