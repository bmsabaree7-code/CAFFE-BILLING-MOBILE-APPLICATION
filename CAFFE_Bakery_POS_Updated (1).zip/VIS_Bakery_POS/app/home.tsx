import React, { useCallback, useState } from 'react';
import { View, Text, Pressable, Alert } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { db } from '../src/db';
import { setSession } from '../src/session';
import { C, R, money } from '../src/theme';
import { businessDayDate, bdSql } from '../src/businessDay';
import { Screen, CornerLogo, SectionTitle, useAuth, useLayout } from '../src/ui';

const modules: [string, string, string, string][] = [
  ['Billing', 'Create bills', 'receipt-text', '/billing'],
  ['Products', 'Menu & pricing', 'package-variant', '/products'],
  ['Cake Orders', 'Custom celebrations', 'cake-variant', '/cakes'],
  ['Customers', 'Customer book', 'account-group', '/customers'],
  ['Purchases', 'Suppliers', 'truck-delivery', '/purchases'],
  ['Reports', 'Sales insights', 'chart-box', '/reports'],
  ['Expenses', 'Track outgoings', 'wallet', '/expenses'],
  ['Bill History', 'Saved receipts', 'history', '/history'],
  ['Admin Security', 'Login settings', 'key-variant', '/settings'],
];

export default function Home() {
  const u = useAuth();
  const { width } = useLayout();
  const [stats, setStats] = useState({ sales: 0, bills: 0, products: 0, low: 0 });

  const refresh = useCallback(() => {
    if (!u) return;
    try {
      const live = db.getFirstSync<any>('SELECT enabled FROM users WHERE id=?', [u.id]);
      if (!live || Number(live.enabled) !== 1) { setSession(null); router.replace('/'); return; }
      const today = businessDayDate();
      const day = db.getFirstSync<any>(`SELECT COALESCE(SUM(total),0) s, COUNT(*) c FROM bills WHERE ${bdSql()}=?`, [today]);
      setStats({
        sales: Number(day?.s || 0),
        bills: Number(day?.c || 0),
        products: Number(db.getFirstSync<any>('SELECT COUNT(*) v FROM products WHERE active=1')?.v || 0),
        low: Number(db.getFirstSync<any>('SELECT COUNT(*) v FROM products WHERE active=1 AND stock<=low_stock')?.v || 0),
      });
    } catch (e) { Alert.alert('Could not load dashboard', String(e)); }
  }, [u?.id]);

  useFocusEffect(useCallback(() => { refresh(); }, [refresh]));
  if (!u) return null;

  const contentW = Math.min(width, 860) - 32;
  const cols = width < 520 ? 2 : width < 820 ? 3 : 4;
  const gap = 12;
  const tileW = Math.floor((contentW - gap * (cols - 1)) / cols);
  const today = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' });

  return (
    <Screen back={false}>
      <View style={{ backgroundColor: C.brownDark, borderRadius: 26, padding: 20 }}>
        <View style={{ position: 'absolute', top: 16, right: 16 }}><CornerLogo /></View>
        <View style={{ paddingRight: 70 }}>
          <Text style={{ color: C.sandDeep, fontSize: 12, letterSpacing: 2 }}>CAFFE · BAKERY POS</Text>
          <Text style={{ fontSize: 25, color: C.white, fontWeight: '900', marginTop: 6 }}>Good day, {u.full_name.split(' ')[0]}</Text>
          <Text style={{ color: C.sandDeep, marginTop: 3, fontSize: 13 }}>{today}</Text>
          <Pressable
            onPress={() => Alert.alert('Sign out', 'Sign out of CAFFE?', [
              { text: 'Cancel', style: 'cancel' },
              { text: 'Sign out', style: 'destructive', onPress: () => { setSession(null); router.replace('/'); } },
            ])}
            style={{ alignSelf: 'flex-start', backgroundColor: C.sand, paddingVertical: 7, paddingHorizontal: 12, borderRadius: 10, marginTop: 12 }}
          >
            <Text style={{ color: C.brownDark, fontWeight: '900', fontSize: 12 }}>SIGN OUT ↗</Text>
          </Pressable>
        </View>
        <View style={{ marginTop: 18, backgroundColor: C.brown, borderRadius: 18, padding: 16 }}>
          <Text style={{ color: C.sand, fontSize: 12, letterSpacing: 1 }}>TODAY'S SALES</Text>
          <Text style={{ color: C.white, fontSize: 32, fontWeight: '900', marginTop: 4 }}>{money(stats.sales)}</Text>
          <Text style={{ color: C.sand, marginTop: 4 }}>{stats.bills} bills completed</Text>
        </View>
        <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
          <View style={{ flex: 1, backgroundColor: C.brown, padding: 13, borderRadius: 14 }}>
            <Text style={{ color: C.sand, fontSize: 11 }}>PRODUCTS</Text>
            <Text style={{ color: C.white, fontSize: 22, fontWeight: '800' }}>{stats.products}</Text>
          </View>
          <View style={{ flex: 1, backgroundColor: C.brown, padding: 13, borderRadius: 14 }}>
            <Text style={{ color: C.sand, fontSize: 11 }}>LOW STOCK</Text>
            <Text style={{ color: stats.low ? '#F2C56B' : C.white, fontSize: 22, fontWeight: '800' }}>{stats.low}</Text>
          </View>
        </View>
      </View>

      <SectionTitle right={<Text style={{ color: C.muted, fontSize: 12 }}>ADMIN</Text>}>Workspace</SectionTitle>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap }}>
        {modules.map(m => (
          <Pressable
            key={m[0]} onPress={() => router.push(m[3] as any)}
            style={({ pressed }) => ({ width: tileW, backgroundColor: pressed ? C.cream : C.white, borderRadius: R.lg, padding: 16, borderWidth: 1, borderColor: C.line })}
          >
            <View style={{ height: 44, width: 44, borderRadius: 12, backgroundColor: C.sand, alignItems: 'center', justifyContent: 'center' }}>
              <MaterialCommunityIcons name={m[2] as any} size={26} color={C.brown} />
            </View>
            <Text style={{ fontSize: 16, fontWeight: '800', color: C.ink, marginTop: 12 }}>{m[0]}</Text>
            <Text style={{ fontSize: 12, color: C.muted, marginTop: 3 }}>{m[1]}</Text>
          </Pressable>
        ))}
      </View>
    </Screen>
  );
}
