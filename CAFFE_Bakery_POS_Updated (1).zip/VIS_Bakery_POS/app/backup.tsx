import React from 'react';
import { Text, Alert } from 'react-native';
import { C } from '../src/theme';
import { Screen, Card, Btn } from '../src/ui';

export default function Backup() {
  return (
    <Screen title="Backup & sync" maxWidth={620}>
      <Card>
        <Text style={{ fontSize: 17, fontWeight: '900', color: C.ink }}>Local database</Text>
        <Text style={{ color: C.muted, marginTop: 8 }}>CAFFE stores billing data in this device's local SQLite database. Cloud sync is not configured in this build.</Text>
        <Btn title="CHECK SYNC STATUS" onPress={() => Alert.alert('Sync status', 'Offline records remain stored on this device. Configure a secure server before enabling cloud sync.')} style={{ marginTop: 15 }} />
      </Card>
    </Screen>
  );
}
