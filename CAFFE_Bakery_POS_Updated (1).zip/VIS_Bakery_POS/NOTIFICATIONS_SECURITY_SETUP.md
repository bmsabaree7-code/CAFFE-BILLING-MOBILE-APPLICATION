# CAFFE POS security and deployment notes

Push notifications are intentionally not part of this version, as requested. No Expo Push or FCM notification sender is configured.

The `server/` folder contains a Node.js + Express + MongoDB backend foundation. Read `server/README.md` and `SECURITY_IMPLEMENTATION_STATUS.md` before deployment.

Important: existing Expo app screens still use local SQLite. The MongoDB backend has not yet been integrated into those screens, so different phones do not share live data yet. Do not treat the backend scaffold as a completed production migration.
