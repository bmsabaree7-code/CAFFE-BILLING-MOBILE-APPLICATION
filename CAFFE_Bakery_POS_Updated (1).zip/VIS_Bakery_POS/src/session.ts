export type User = { id: number; username: string; role: 'admin'; full_name: string; sessionStartedAt?: number };
let current: User | null = null;
const DAY = 24 * 60 * 60 * 1000;
// Keeps the original sessionStartedAt when the same session is updated (e.g. username change).
export const setSession = (u: User | null) => {
  current = u ? { ...u, sessionStartedAt: u.sessionStartedAt ?? Date.now() } : null;
};
export const getSession = () => {
  if (current?.sessionStartedAt && Date.now() - current.sessionStartedAt > DAY) current = null;
  return current;
};
export const clearSession = () => { current = null; };
