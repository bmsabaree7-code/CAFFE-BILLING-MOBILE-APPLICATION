// CAFFE palette: beige base, sandal surfaces, brown accents, white cards.
export const C = {
  bg: '#F6EFE4',        // beige page background
  cream: '#FBF6EC',     // soft cream (inputs on sand, hero text)
  surface: '#FFFFFF',   // white cards
  sand: '#EADBC4',      // sandal
  sandDeep: '#D8C2A0',  // deeper sandal (borders / pressed)
  brown: '#6B4A2F',     // primary brown
  brownDark: '#3F2B1B', // text / hero
  brownSoft: '#8C6A4A', // secondary brown
  ink: '#3F2B1B',
  muted: '#8A7560',
  line: '#E5D6BF',
  green: '#4E7B55',
  greenLight: '#E3EEDF',
  red: '#B3402F',
  redLight: '#FBE9E4',
  gold: '#B98A2E',
  white: '#FFFFFF',
};
export const R = { sm: 10, md: 14, lg: 20 };
export const money = (n: number) =>
  '₹' + (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
