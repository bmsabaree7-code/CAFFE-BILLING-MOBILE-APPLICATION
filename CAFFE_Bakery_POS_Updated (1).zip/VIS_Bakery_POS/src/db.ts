import * as SQLite from 'expo-sqlite';
import * as Crypto from 'expo-crypto';

export const db = SQLite.openDatabaseSync('vis_bakery.db');
export async function hashPassword(p:string){ return await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256,p); }

export async function initDb(){
 db.execSync(`
 PRAGMA journal_mode = WAL;
 CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL, full_name TEXT NOT NULL, phone TEXT DEFAULT '', enabled INTEGER DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT DEFAULT 'Bakery', price REAL NOT NULL DEFAULT 0, cost REAL NOT NULL DEFAULT 0, gst REAL NOT NULL DEFAULT 0, stock REAL NOT NULL DEFAULT 0, low_stock REAL NOT NULL DEFAULT 5, barcode TEXT DEFAULT '', expiry TEXT DEFAULT '', active INTEGER DEFAULT 1, priority INTEGER NOT NULL DEFAULT 999);
 CREATE TABLE IF NOT EXISTS bills(id TEXT PRIMARY KEY, bill_no INTEGER, user_id INTEGER, cashier_name TEXT, customer TEXT DEFAULT '', subtotal REAL, discount REAL, gst REAL, total REAL, payment TEXT, bill_type TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, synced INTEGER DEFAULT 0);
 CREATE TABLE IF NOT EXISTS bill_items(id INTEGER PRIMARY KEY AUTOINCREMENT, bill_id TEXT, product_id INTEGER, product_name TEXT, qty REAL, price REAL, gst_rate REAL, line_total REAL, cost_price REAL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS cake_orders(id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT, phone TEXT, weight TEXT, flavour TEXT, design TEXT, due_date TEXT, total REAL, advance REAL DEFAULT 0, status TEXT DEFAULT 'Booked', notes TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT DEFAULT '', balance REAL DEFAULT 0, notes TEXT DEFAULT '');
 CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT DEFAULT '', notes TEXT DEFAULT '');
 CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, amount REAL, category TEXT DEFAULT 'General', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
 CREATE TABLE IF NOT EXISTS stock_log(id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, delta REAL, reason TEXT, user_name TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
 `);
 try { db.execSync('ALTER TABLE products ADD COLUMN priority INTEGER NOT NULL DEFAULT 999'); } catch {}
 try { db.execSync('ALTER TABLE bill_items ADD COLUMN cost_price REAL DEFAULT 0'); } catch {}
 try { db.execSync("ALTER TABLE cake_orders ADD COLUMN completed_bill_id TEXT DEFAULT ''"); } catch {}
 try { db.execSync("ALTER TABLE cake_orders ADD COLUMN status TEXT DEFAULT 'Pending'"); } catch {}
 const row=db.getFirstSync<any>("SELECT id FROM users WHERE role='admin' LIMIT 1");
 if(!row){ const h=await hashPassword('ADMIN123'); db.runSync('INSERT OR IGNORE INTO users(username,password_hash,role,full_name,enabled) VALUES(?,?,?,?,1)',['ADMIN',h,'admin','CAFFE Admin']); }
}

export function nextBillNo(): number {
  return Number(db.getFirstSync<any>('SELECT COALESCE(MAX(bill_no),0)+1 n FROM bills')?.n) || 1;
}
