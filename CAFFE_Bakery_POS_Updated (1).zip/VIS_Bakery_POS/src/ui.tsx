import React, { useEffect } from 'react';
import {
  View, Text, Pressable, ScrollView, TextInput, Image, KeyboardAvoidingView, Platform,
  useWindowDimensions, StyleProp, ViewStyle, TextInputProps,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { C, R } from './theme';
import { getSession, User } from './session';

/** Phone / tablet breakpoints. */
export function useLayout() {
  const { width, height } = useWindowDimensions();
  return { width, height, isTablet: width >= 700, isWide: width >= 820 };
}

/** Returns the signed-in user, or sends the person to the login screen. */
export function useAuth(): User | null {
  const u = getSession();
  useEffect(() => { if (!u) router.replace('/'); }, [u]);
  return u;
}

export function goBack() {
  if (router.canGoBack()) router.back(); else router.replace('/home');
}

/** Small logo tile. Used ONLY in the top-right corner of the dashboard. */
export function CornerLogo({ size = 52 }: { size?: number }) {
  return (
    <View style={{ width: size, height: size, borderRadius: 14, backgroundColor: C.white, overflow: 'hidden', borderWidth: 1, borderColor: C.sand }}>
      <Image source={require('../assets/icon.png')} style={{ width: size, height: size }} resizeMode="contain" />
    </View>
  );
}

type ScreenProps = {
  title?: string; subtitle?: string; back?: boolean; right?: React.ReactNode;
  scroll?: boolean; maxWidth?: number; children?: React.ReactNode;
  scrollRef?: React.RefObject<ScrollView | null>;
};

/** Page wrapper: safe-area aware, centred max-width container so phone and tablet both look right. */
export function Screen({ title, subtitle, back = true, right, scroll = true, maxWidth = 860, children, scrollRef }: ScreenProps) {
  const ins = useSafeAreaInsets();
  const header = (title || back) ? (
    <View style={{ marginBottom: 14 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 36 }}>
        {back ? (
          <Pressable onPress={goBack} hitSlop={10} style={{ paddingVertical: 6, paddingRight: 14 }}>
            <Text style={{ color: C.brown, fontWeight: '800', fontSize: 15 }}>‹  Back</Text>
          </Pressable>
        ) : <View />}
        {right}
      </View>
      {title ? <Text style={{ fontSize: 28, fontWeight: '900', color: C.ink, marginTop: 6 }}>{title}</Text> : null}
      {subtitle ? <Text style={{ color: C.muted, marginTop: 3 }}>{subtitle}</Text> : null}
    </View>
  ) : null;

  if (!scroll) {
    return (
      <View style={{ flex: 1, backgroundColor: C.bg, paddingTop: ins.top + 8, paddingBottom: ins.bottom + 8 }}>
        <View style={{ flex: 1, width: '100%', maxWidth, alignSelf: 'center', paddingHorizontal: 16 }}>
          {header}
          {children}
        </View>
      </View>
    );
  }
  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: C.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView ref={scrollRef} keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingTop: ins.top + 8, paddingBottom: ins.bottom + 40 }}>
        <View style={{ width: '100%', maxWidth, alignSelf: 'center', paddingHorizontal: 16 }}>
          {header}
          {children}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

export function Card({ children, style, tone = 'white' }: { children?: React.ReactNode; style?: StyleProp<ViewStyle>; tone?: 'white' | 'sand' | 'brown' }) {
  const bg = tone === 'brown' ? C.brownDark : tone === 'sand' ? C.sand : C.white;
  return <View style={[{ backgroundColor: bg, borderRadius: R.lg, padding: 16, borderWidth: tone === 'white' ? 1 : 0, borderColor: C.line }, style]}>{children}</View>;
}

export function SectionTitle({ children, right }: { children: React.ReactNode; right?: React.ReactNode }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 20, marginBottom: 10 }}>
      <Text style={{ fontSize: 19, fontWeight: '900', color: C.ink }}>{children}</Text>
      {right}
    </View>
  );
}

export function Field({ label, style, ...p }: { label?: string } & TextInputProps) {
  return (
    <View style={{ marginTop: 10 }}>
      {label ? <Text style={{ color: C.brownSoft, fontWeight: '700', fontSize: 12, marginBottom: 5, letterSpacing: 0.4 }}>{label.toUpperCase()}</Text> : null}
      <TextInput
        placeholderTextColor={C.muted}
        {...p}
        style={[{ backgroundColor: C.white, borderWidth: 1, borderColor: C.sandDeep, borderRadius: R.sm, paddingHorizontal: 13, paddingVertical: Platform.OS === 'ios' ? 13 : 10, color: C.ink, fontSize: 15 }, style]}
      />
    </View>
  );
}

type Variant = 'primary' | 'soft' | 'danger' | 'ghost' | 'success';
export function Btn({ title, onPress, variant = 'primary', small, disabled, style }: {
  title: string; onPress: () => void; variant?: Variant; small?: boolean; disabled?: boolean; style?: StyleProp<ViewStyle>;
}) {
  const map: Record<Variant, { bg: string; fg: string; border: string }> = {
    primary: { bg: C.brown, fg: C.white, border: C.brown },
    soft: { bg: C.sand, fg: C.brownDark, border: C.sand },
    danger: { bg: C.redLight, fg: C.red, border: '#E3B3A9' },
    ghost: { bg: 'transparent', fg: C.brown, border: C.sandDeep },
    success: { bg: C.green, fg: C.white, border: C.green },
  };
  const v = map[variant];
  return (
    <Pressable
      onPress={onPress} disabled={disabled} accessibilityRole="button"
      style={({ pressed }) => [{ backgroundColor: v.bg, borderColor: v.border, borderWidth: 1, borderRadius: R.md, paddingVertical: small ? 10 : 14, paddingHorizontal: small ? 14 : 18, alignItems: 'center', justifyContent: 'center', opacity: disabled ? 0.45 : pressed ? 0.8 : 1 }, style]}
    >
      <Text style={{ color: v.fg, fontWeight: '800', fontSize: small ? 13 : 15 }}>{title}</Text>
    </Pressable>
  );
}

export function Segmented<T extends string>({ options, value, onChange }: { options: [T, string][]; value: T; onChange: (v: T) => void }) {
  return (
    <View style={{ flexDirection: 'row', backgroundColor: C.sand, borderRadius: R.md, padding: 4, gap: 4 }}>
      {options.map(([k, label]) => {
        const on = k === value;
        return (
          <Pressable key={k} onPress={() => onChange(k)} style={{ flex: 1, paddingVertical: 10, borderRadius: R.sm, alignItems: 'center', backgroundColor: on ? C.brown : 'transparent' }}>
            <Text style={{ fontWeight: '800', color: on ? C.white : C.brownDark, fontSize: 13 }}>{label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export function Empty({ text }: { text: string }) {
  return <Text style={{ padding: 24, textAlign: 'center', color: C.muted }}>{text}</Text>;
}
