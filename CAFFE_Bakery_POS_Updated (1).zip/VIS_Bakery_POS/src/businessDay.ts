/** CAFFE business day uses the device's local time zone and rolls over at 00:01. */
export function businessDayDate(d = new Date()): string {
  const adjusted = new Date(d.getTime());
  if (adjusted.getHours() === 0 && adjusted.getMinutes() === 0) adjusted.setDate(adjusted.getDate() - 1);
  const y = adjusted.getFullYear();
  const m = String(adjusted.getMonth() + 1).padStart(2, '0');
  const day = String(adjusted.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
/** Same 00:01 rollover, expressed in SQL so queries match businessDayDate(). */
export const bdSql = (col = 'created_at') => `date(datetime(${col},'-1 minute'))`;
export function localDateTimeString(d = new Date()): string {
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}
export function csvCell(value: unknown): string {
  const s = String(value ?? '');
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
export function isValidDate(s: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(s + 'T00:00:00');
  return !isNaN(d.getTime()) && localDateTimeString(d).startsWith(s);
}
export function dateOffset(days: number): string {
  const d = new Date(); d.setDate(d.getDate() + days);
  return localDateTimeString(d).slice(0, 10);
}
