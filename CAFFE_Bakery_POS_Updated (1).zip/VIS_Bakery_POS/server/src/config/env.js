import 'dotenv/config';
import { z } from 'zod';
const schema=z.object({NODE_ENV:z.string().default('development'),PORT:z.coerce.number().default(4000),MONGODB_URI:z.string().min(1),JWT_ACCESS_SECRET:z.string().min(32),JWT_REFRESH_SECRET:z.string().min(32),ACCESS_TOKEN_MINUTES:z.coerce.number().default(15),REFRESH_TOKEN_DAYS:z.coerce.number().default(7),CORS_ORIGINS:z.string().default('')});
const parsed=schema.safeParse(process.env);
if(!parsed.success){console.error('Invalid server environment:',parsed.error.flatten().fieldErrors);process.exit(1)}
export const env=parsed.data;
