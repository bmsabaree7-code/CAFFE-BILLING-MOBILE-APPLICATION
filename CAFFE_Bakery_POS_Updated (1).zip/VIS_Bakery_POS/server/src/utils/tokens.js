import crypto from 'node:crypto';import jwt from 'jsonwebtoken';import {env} from '../config/env.js';
export const hashToken=(v)=>crypto.createHash('sha256').update(v).digest('hex');
export function issueAccess(user){return jwt.sign({sub:String(user._id),shopId:String(user.shopId),role:user.role,ver:user.tokenVersion},env.JWT_ACCESS_SECRET,{expiresIn:`${env.ACCESS_TOKEN_MINUTES}m`,issuer:'caffe-pos-api',audience:'caffe-pos-app'});}
export function issueRefresh(user){return jwt.sign({sub:String(user._id),shopId:String(user.shopId),ver:user.tokenVersion,jti:crypto.randomUUID()},env.JWT_REFRESH_SECRET,{expiresIn:`${env.REFRESH_TOKEN_DAYS}d`,issuer:'caffe-pos-api',audience:'caffe-pos-refresh'});}
