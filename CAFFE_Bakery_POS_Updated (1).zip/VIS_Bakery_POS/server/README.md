# CAFFE POS secure MongoDB API (starter)

This is a Node.js/Express + MongoDB backend scaffold included alongside the existing Expo app. It provides tenant-scoped Mongoose models, Argon2id password verification, short-lived JWT access tokens, rotating refresh sessions, server-side role checks, input validation, Helmet headers, CORS allow-list, request limits and rate limiting. Push notifications are intentionally not included, per request.

## Important integration status
The current Expo screens still use the existing on-device SQLite database. This backend is **not yet wired into those screens**, so creating a bill/product/order in the current APK will not automatically save it to MongoDB or sync another phone. This ZIP supplies the backend foundation and integration contract, not a completed migration of every screen. Do not use it for live shop data until mobile API integration and security tests are completed.

## Setup
1. Create a MongoDB Atlas project and database user with least-privilege access. Allow network access only from your deployed API host where possible; never expose MongoDB credentials in the mobile app.
2. Copy `.env.example` to `.env` and fill values. Generate two independent secrets with `node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"` (run twice).
3. `npm install`
4. `npm run check`
5. `npm run dev`
6. Check `GET /health`.

## API routes
- `POST /api/auth/login` body `{shopId, username, password}`
- `POST /api/auth/refresh` body `{refreshToken}` (rotates refresh token)
- `POST /api/auth/logout` with Bearer access token
- `GET /api/auth/me`
- `GET/POST /api/products`
- `GET/POST /api/cakes`; `PATCH /api/cakes/:id/status`
- `GET/POST /api/bills`
- `GET/POST /api/customers`
- `GET/POST /api/expenses` (admin/accountant)

All business documents are scoped by `shopId` from the verified access token. A trusted onboarding/admin provisioning flow must create the first shop and admin user using Argon2id; public admin signup is intentionally absent. Never accept a role or shopId from a normal client request as authorization evidence.

## Before production
- Deploy behind HTTPS/TLS; set exact CORS origins and secrets in hosting environment variables.
- Add trusted shop/admin provisioning, password reset, MFA, audit events, request tracing and alerting.
- Add atomic stock decrement and idempotency keys for bill creation; add pagination and stricter per-role field permissions.
- Add automated tests for cross-tenant access, role bypass, refresh replay, disabled users, validation and concurrency.
- Configure MongoDB backups and test restoration.
- Do not store access/refresh tokens in AsyncStorage; use platform secure storage in the mobile app.
