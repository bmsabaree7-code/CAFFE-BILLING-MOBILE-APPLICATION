# VIS name and icon note

The included icon is a simple original pastry-inspired illustration generated for this project. No third-party brand logo, character, or stock image is bundled.

This does **not** constitute a legal copyright or trademark clearance. “VIS” is a short name that may already be used by other businesses. Before commercial release, search relevant Indian trademark records (especially the IP India public search) and app stores, and consult a trademark professional if needed. Avoid using another bakery's logo or brand identity.
