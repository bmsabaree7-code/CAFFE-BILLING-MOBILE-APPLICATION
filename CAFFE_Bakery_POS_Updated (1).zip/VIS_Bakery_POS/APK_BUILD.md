# Build CAFFE into an Android APK

## Option A: EAS cloud build (simplest)
```powershell
npm install
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile preview
```
Open the build URL shown in the terminal, download the APK, copy it to the phone and install it.

## Option B: Local build
Needs Android Studio, Android SDK and a compatible JDK.
```powershell
npx expo prebuild --platform android --clean
cd android
.\gradlew assembleRelease
```
APK: `android/app/build/outputs/apk/release/app-release.apk`

## Before distributing
- Change the default admin password (`ADMIN123`).
- Increase `version` and `android.versionCode` in `app.json` for every release.
- Test offline billing, stock reduction and bill deletion on a real device and a tablet.
- Validate GST settings with a qualified accountant.
