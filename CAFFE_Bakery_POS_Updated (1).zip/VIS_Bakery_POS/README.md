# CAFFE Bakery POS

Offline-first bakery point-of-sale app built with Expo / React Native and local SQLite storage.
Works on Android phones and tablets (the layout adapts: phone = single column + Products/Cart tabs, tablet = two panes).

Single login: **Admin only**. The cashier module has been removed.

- Default login: `ADMIN` / `ADMIN123` (change it in **Admin Security** before real use)

---

## 1. Run the app (development)

Requirements: Node.js LTS (20 or 22), npm, and the **Expo Go** app on an Android phone (or Android Studio emulator).

```powershell
# 1. open terminal inside the VIS_Bakery_POS folder
npm install

# 2. (recommended) make sure every package matches your Expo SDK version
npx expo install --check

# 3. start the dev server
npx expo start
```

- Scan the QR code with Expo Go, or press `a` for an Android emulator.
- If the phone cannot connect, use `npx expo start --tunnel`.
- Clear cache if something looks stale: `npx expo start -c`

Useful checks:

```powershell
npm run typecheck     # TypeScript check
npm run doctor        # expo-doctor: finds dependency/config problems
```

> Web preview is not supported: the app depends on native SQLite. Test on a phone/tablet or emulator.

---

## 2. Convert to APK

### Option A: EAS cloud build (easiest, needs a free Expo account)

```powershell
npm install -g eas-cli
eas login
eas build:configure          # only the first time
eas build --platform android --profile preview
```

When the build finishes, open the link shown in the terminal, download the `.apk` and install it on the phone
(allow "install from unknown sources" if Android asks).

`preview` = installable APK. `production` builds an `.aab` for Play Store:

```powershell
eas build --platform android --profile production
```

### Option B: Local build (Android Studio + JDK required)

```powershell
npx expo prebuild --platform android --clean
cd android
.\gradlew assembleRelease        # Windows
# ./gradlew assembleRelease      # macOS / Linux
```

APK output: `android/app/build/outputs/apk/release/app-release.apk`

Before a new release raise `version` in `app.json` and `android.versionCode` (must increase every time).

---

## 3. How to change things in the app

| I want to change... | Edit this |
|---|---|
| Colours (beige / sandal / brown / white) | `src/theme.ts` (object `C`) |
| Buttons, inputs, cards, page layout, phone/tablet breakpoints | `src/ui.tsx` |
| App name, version, package id, splash/icon paths | `app.json` |
| App icon / splash image | replace files in `assets/` (`icon.png`, `adaptive-icon.png`, `splash.png`, 1024x1024) |
| Where the logo appears (currently only top-right corner of the dashboard) | `CornerLogo` in `src/ui.tsx`, used in `app/home.tsx` |
| Dashboard tiles (add / remove / rename) | `modules` list at the top of `app/home.tsx` |
| Billing screen (cart, +/- qty, clear bill, discount, payment methods) | `app/billing.tsx` |
| Product form and fields | `app/products.tsx` (and the `products` table in `src/db.ts`) |
| Database tables / new columns | `initDb()` in `src/db.ts` (add `ALTER TABLE ... ADD COLUMN` inside `try/catch`) |
| Default admin username / password | `initDb()` in `src/db.ts` (only used when no admin exists) |
| Session length (24h) | `DAY` in `src/session.ts` |
| Business-day rollover (00:01) | `src/businessDay.ts` |
| CSV export columns | `exportSessionCsv` in `app/reports.tsx` |
| Currency symbol / number format | `money()` in `src/theme.ts` |

After editing, the running dev server reloads automatically. For a new APK run the build command again.

---

## 4. What the app does

- **Billing**: search/add products, `-` / `+` / typed quantity, remove line, discount, GST or normal bill, Cash/UPI/Card/Credit,
  **Clear / Cancel bill**, running bill numbers. Stock is reduced on save. Credit bills add to the matching customer's balance.
- **Products**: buy cost, selling price, GST, stock, low-stock alert. Delete archives the product (old bills stay).
- **Cake orders**: Pending -> Done creates a bill in history.
- **Customers / Suppliers / Expenses**: add and delete; customer credit can be marked paid.
- **Bill history**: tap a bill for items, delete a bill (stock and credit are restored).
- **Reports**: Today / 7 days / 30 days / All; sales, buy cost, gross profit, expenses; session CSV export.
- Data lives only on the device (SQLite). There is no cloud sync between devices.

## 5. Notes

- Business day rolls over at 00:01 device time; dashboard and reports use the same rule.
- Receipt printing and cloud sync are not implemented. See `NOTIFICATIONS_SECURITY_SETUP.md` and
  `SECURITY_IMPLEMENTATION_STATUS.md` for what a shared backend would need (`server/` is an optional, separate starter).
- Take regular backups of the phone/app data; uninstalling the app deletes the local database.
